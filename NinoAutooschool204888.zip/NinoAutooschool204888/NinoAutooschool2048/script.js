let lattext = document.getElementById("lat");
let longtext = document.getElementById("long");
let nearestDistance = document.getElementById("dist");
let userLocationMarker;
let action = document.getElementById("action");
let playedPoints = new Set();


let polylineCoords = [
    [41.9285114,42.0305157],
  [41.92760941, 42.03096092],
  [41.92524266, 42.02552676],
  [41.92302749, 42.01927722],
  [41.92245673, 42.02060759],
  [41.92022949, 42.02306986],
  [41.91965072, 42.02350438],
  [41.91962677, 42.02216327],
  [41.9189003, 42.01848328],
  [41.91902004, 42.01603711],
  [41.91897614, 42.01449215],
  [41.9194232, 42.01378405],
  [41.91995407, 42.01336026],
  [41.91960681, 42.00984657],
  [41.91934736, 42.00903118],
  [41.91977046, 42.00662792],
  [41.92019357, 42.00616658],
  [41.92114754, 42.00589836],
  [41.92161853, 42.00626314],
  [41.92179415, 42.00598419],
  [41.92159857, 42.0056355],
  [41.92118745, 42.00541019],
  [41.92113556, 42.00242758],
  [41.91776667, 42.00235784],
  [41.91739544, 42.00105429],
  [41.91720783, 42.00099528],
  [41.91662503, 42.00176775],
  [41.91653322, 42.00279236],
  [41.91679668, 42.00300694],
  [41.91724775, 42.00249195],
  [41.91997802, 42.00261533],
  [41.92103977, 42.00254023],
  [41.92113157, 42.00567842],
  [41.92149878, 42.0062685],
  [41.9222372, 42.00586081],
  [41.92254454, 42.00587153],
  [41.92227711, 42.00765789],
  [41.92382975, 42.00748622],
  [41.92364615, 42.00557649],
  [41.92312329, 42.00560331],
  [41.92316719, 42.00200915],
  [41.92353439, 42.00186431],
  [41.92423686, 42.00107038],
  [41.92535441, 42.0024544],
  [41.92543025, 42.00330734],
  [41.92662361, 42.0031625],
  [41.92717438, 42.00473428],
  [41.92724622, 42.00526536],
  [41.92547814, 42.00540483],
  [41.92390559, 42.00551748],
  [41.9214469, 42.00573742],
  [41.92138303, 42.00593054],
  [41.92146685, 42.00655818],
  [41.92080427, 42.00893998],
  [41.92140299, 42.01248586],
  [41.92252059, 42.01198161],
  [41.92404129, 42.01547384],
  [41.92519077, 42.01906264],
  [41.92315123, 42.01985121],
  [41.92416502, 42.02294111],
  [41.92529055, 42.02575743],
  [41.92756551, 42.03107893],
  [41.92802847, 42.03081608]
];


let checkpoints = [
    [41.9285114,42.0305157, "start"],               //1
    [41.9282919, 42.0306122, "right"],              //2
    [41.9279486, 42.0307463, "Sright"],            //3

    [41.9275575, 42.0307034, "directlyunstillsigh"], //4
    [41.9250152, 42.0248508, "500left"],            //5
    [41.9242768, 42.0227695, "300left"],             //6
    [41.9234147, 42.0202214, "Sleft"],


    [41.9227498, 42.0199266, "directly"],
    [41.9217981, 42.0213532, "300right"],
    [41.9202828, 42.0229437, "Sright"],        //10


    [41.9195908, 42.0229036, "directlyunstillsigh"], //11
    [41.9193474, 42.0205057, "500right"],
    [41.9189123, 42.0185155, "300right"],
    [41.9190005, 42.0154197, "Sright"], //14

    [41.919024, 42.0144331, "directlyunstillsigh"],
    [41.9196707, 42.0071322, "right"],
    [41.9208841, 42.0059949, "leftonCircle"],
    [41.9215674, 42.0061794, "left"],

    [41.9214669, 42.0056462, "Sright"], //19

    [41.9211389, 42.0034284, "Sleft"],//20



    [41.9208961, 42.0024222, "directly"], //Modern 21
    [41.91999, 42.0024866, "300right"],



    [41.9182656, 42.0024061, "rightleft"], //right then left  23
    

    [41.9176291, 42.0019572, "leftonCircle"], //24
    [41.917144, 42.0010972, "directly"], // near circle   25
    [41.9165442, 42.0022132, "Sleft"],  //under the bridge  26

    [41.9169364, 42.0028407, "Sright"],//27

 
    [41.9185822, 42.0025636, "300right"], //28

    [41.9202015, 42.0025563, "Sright"],


    [41.9210817, 42.0046017, "leftonCircle"], //makamaia 30

//////////////////////////////////////////////////////////////////////////

    [41.9221254, 42.0058662, "Sright"], //avtos painting,zebra 31


    [41.9224448, 42.0064884, "Sleft"], //32
    [41.9230395, 42.0076246, "Sleft"],
    [41.9237554, 42.0064432, "Sleft"],
    [41.9235025, 42.0055389, "rightonCircle"], //teatri 35


    [41.923167, 42.0048788, "directly"],
    [41.9231796, 42.0029604, "Sright"], //church  37
    [41.9237924, 42.0016697, "Sright"], //elkectro
    [41.9253006, 42.0025856, "Sleft"], //shool
    [41.9256697, 42.0032966, "Sright"], //40

    [41.9269509, 42.004264, "rightonCircle"], //pubTerassa
    [41.9270826, 42.0052678, "directlyunstillsigh"], //42
    [41.9229916, 42.0055926, "leftonCircle"], //zebra back 43

    
    [41.9214429, 42.0065635, "directly"],//44
    [41.9208322, 42.0088649, "300left"], //45
    [41.9210885, 42.010799, "Sleft"], //kalonkamde 4466
    [41.9220177, 42.0122606, "Sright"],   


    [41.9226363, 42.0123303, "directly"], //stadiontan
    [41.9241211, 42.0156616, "300right"],
    [41.9249739, 42.0184644, "Sright"],
    [41.9240098, 42.0194851, "Sleft"],//51


    [41.923259, 42.0201838, "directlyunstillsigh"], //52
    [41.9253265, 42.0256823, "500left"],
    [41.9262165, 42.027812, "300left"],
    [41.9270095, 42.0297221, "Sleft"],              //55

    
    [41.9279486, 42.0307946, "Sleft"],
    [41.9287229, 42.0304674, "stop"] //????   57
  ];
  



// Define the audio files for each option
const audioFiles = {

    "start": "audio/start.mp3",
    "start3": "audio/start3.mp3",

    "500left": "audio/500left.mp3",
    "500right": "audio/500right.mp3",
    
    "300left": "audio/300left.mp3",
    "300right": "audio/300right.mp3",

    "100left": "audio/100left.mp3",
    "100right": "audio/100right.mp3",
  
    "left": "audio/left.mp3",
    "Sleft": "audio/Sleft.mp3",

    "right": "audio/right.mp3",
    "Sright": "audio/Sright.mp3",
  

    "directly": "audio/directly.mp3",
    "directlyunstillsigh": "audio/directlyunstillsigh.mp3",

    "leftonCircle": "audio/leftonCircle.mp3",
    "rightonCircle": "audio/rightonCircle.mp3",

    "300leftonCircle": "audio/300leftonCircle.mp3",
    "300rightonCircle": "audio/300rightonCircle.mp3",
    "500leftonCircle": "audio/500leftonCircle.mp3",
    "500rightonCircle": "audio/500rightonCircle.mp3",

    "rightleft": "audio/rightleft.mp3",
    

    "stop": "audio/stop.mp3"
  

};


const audioFilesRussian = {

    "start": "audior/start.mp3",
    "start3": "audior/start3.mp3",

    "500left": "audior/500left.mp3",
    "500right": "audior/500right.mp3",
    
    "300left": "audior/300left.mp3",
    "300right": "audior/300right.mp3",

    "100left": "audior/100left.mp3",
    "100right": "audior/100right.mp3",
  
    "left": "audior/left.mp3",
    "Sleft": "audior/Sleft.mp3",
    "right": "audior/right.mp3",
    "Sright": "audior/Sright.mp3",
    "directly": "audior/directly.mp3",
    "directlyunstillsigh": "audior/directlyunstillsigh.mp3",
    "leftonCircle": "audior/leftonCircle.mp3",
    "rightonCircle": "audior/rightonCircle.mp3",
    "300leftonCircle": "audior/300leftonCircle.mp3",
    "300rightonCircle": "audior/300rightonCircle.mp3",
    "500leftonCircle": "audior/500leftonCircle.mp3",
    "500rightonCircle": "audior/500rightonCircle.mp3",
    "rightleft": "audior/rightleft.mp3",
    "stop": "audior/stop.mp3"
  
};

const audioFilesTurkish = {
    "start": "audiotr/start.mp3",
    "start3": "audiotr/start3.mp3",
    "500left": "audiotr/500left.mp3",
    "500right": "audiotr/500right.mp3",
    "300left": "audiotr/300left.mp3",
    "300right": "audiotr/300right.mp3",
    "100left": "audiotr/100left.mp3",
    "100right": "audiotr/100right.mp3",
    "left": "audiotr/left.mp3",
    "Sleft": "audiotr/Sleft.mp3",
    "right": "audiotr/right.mp3",
    "Sright": "audiotr/Sright.mp3",
    "directly": "audiotr/directly.mp3",
    "directlyunstillsigh": "audiotr/directlyunstillsigh.mp3",
    "leftonCircle": "audiotr/leftonCircle.mp3",
    "rightonCircle": "audiotr/rightonCircle.mp3",
    "300leftonCircle": "audiotr/300leftonCircle.mp3",
    "300rightonCircle": "audiotr/300rightonCircle.mp3",
    "500leftonCircle": "audiotr/500leftonCircle.mp3",
    "500rightonCircle": "audiotr/500rightonCircle.mp3",
    "rightleft": "audiotr/rightleft.mp3",
    "stop": "audiotr/stop.mp3"
};


const audioFilesEnglish = {
    "start": "audioen/start.mp3",
    "start3": "audioen/start3.mp3",
    "500left": "audioen/500left.mp3",
    "500right": "audioen/500right.mp3",
    "300left": "audioen/300left.mp3",
    "300right": "audioen/300right.mp3",
    "100left": "audioen/100left.mp3",
    "100right": "audioen/100right.mp3",
    "left": "audioen/left.mp3",
    "Sleft": "audioen/Sleft.mp3",
    "right": "audioen/right.mp3",
    "Sright": "audioen/Sright.mp3",
    "directly": "audioen/directly.mp3",
    "directlyunstillsigh": "audioen/directlyunstillsigh.mp3",
    "leftonCircle": "audioen/leftonCircle.mp3",
    "rightonCircle": "audioen/rightonCircle.mp3",
    "300leftonCircle": "audioen/300leftonCircle.mp3",
    "300rightonCircle": "audioen/300rightonCircle.mp3",
    "500leftonCircle": "audioen/500leftonCircle.mp3",
    "500rightonCircle": "audioen/500rightonCircle.mp3",
    "rightleft": "audioen/rightleft.mp3",
    "stop": "audioen/stop.mp3"
};







// Define the options list
const options = ["100right", "right", "left", "100right", "100left","right", "left", "100right", "100left", "left", "100left", "left"]; // Example options list


let sumLat = polylineCoords.reduce((acc, val) => acc + val[0], 0);
let sumLng = polylineCoords.reduce((acc, val) => acc + val[1], 0);

let avgLat = sumLat / polylineCoords.length;
let avgLng = sumLng / polylineCoords.length;

// let map = L.map('map').setView([avgLat, avgLng], 16.3);

// L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
//     attribution: 'Map data &copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a> contributors'
// }).addTo(map);

// Existing map setup code
//let map = L.map('map').setView([41.9217662, 42.0145082], 15.4);

let map = L.map('map', {
    center: [41.9217662, 42.0145082],
    zoom: 15.4,
    dragging: false,// Disable map dragging
    touchZoom: false, // Optionally disable zooming with touch gestures
    scrollWheelZoom: false // Optionally disable zooming with the scroll wheel
});


// Define the default and satellite layers
let defaultLayer = L.tileLayer('https://{s}.tile.openstreetmap.fr/hot/{z}/{x}/{y}.png', {
    attribution: '©OpenStreetMap contributors, Tiles style by Humanitarian OpenStreetMap Team hosted by OpenStreetMap France'
});

let satelliteLayer = L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', {
    attribution: 'Tiles &copy; Esri &mdash; Source: Esri, i-cubed, USDA, USGS, AEX, GeoEye, Getmapping, Aerogrid, IGN, IGP, UPR-EGP, and the GIS User Community'
}).addTo(map); // Add the satellite layer to the map

// Add functionality to toggle button
document.getElementById('toggleMap').addEventListener('click', function() {
    if (map.hasLayer(defaultLayer)) {
        map.removeLayer(defaultLayer);
        map.addLayer(satelliteLayer);
        // this.textContent = 'Toggle Default View'; // Change button text accordingly
    } else {
        map.removeLayer(satelliteLayer);
        map.addLayer(defaultLayer);
        // this.textContent = 'Toggle Satellite View'; // Reset button text
    }
});


//დროპ

document.addEventListener('DOMContentLoaded', function() {
    const dropdown = document.querySelector('.dropdown');
    const dropbtn = document.querySelector('.dropbtn');
  
    dropbtn.addEventListener('click', function(event) {
      event.stopPropagation(); // Prevent the click event from bubbling up to the document
      dropdown.classList.toggle('show');
    });
  
    // Close the dropdown if the user clicks outside of it
    document.addEventListener('click', function(event) {
      if (!dropdown.contains(event.target)) {
        dropdown.classList.remove('show');
      }
    });
  });
  







let checkpointMarkers = []; // Initialize an empty array to store checkpoint markers

polylineCoords.forEach((coord, index) => {
    let color = 'cyan';
    if (index === 0) color = 'red'; // Start point
    else if (index === polylineCoords.length - 1) color = 'black'; // End point

    let circleMarker = L.circleMarker(coord, {
        color: color,
        fillColor: 'blue',
        fillOpacity: 1,
        radius:5
    }).addTo(map);

    //animateBreathing(circleMarker); // Apply breathing animation to each marker

    // Store the marker and its index or any other relevant info
    checkpointMarkers.push({
        marker: circleMarker,
        index: index,
        coordinates: coord,
        description: `Checkpoint ${index + 1}`
    });
});



let polyline = L.polyline(polylineCoords, {color: 'purple', weight: 6, dashArray: '12, 12'}).addTo(map);


// Function to calculate distance between two points using Haversine formula
function calculateDistance(lat1, lon1, lat2, lon2) {
  const R = 6371e3; // Radius of the Earth in meters
  const φ1 = lat1 * Math.PI / 180; // φ, λ in radians
  const φ2 = lat2 * Math.PI / 180;
  const Δφ = (lat2 - lat1) * Math.PI / 180;
  const Δλ = (lon2 - lon1) * Math.PI / 180;

  const a = Math.sin(Δφ / 2) * Math.sin(Δφ / 2) +
            Math.cos(φ1) * Math.cos(φ2) *
            Math.sin(Δλ / 2) * Math.sin(Δλ / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

  const distance = R * c; // Distance in meters
  return distance;
}



// function playAudio(audioKey) {
//   if (audioFiles.hasOwnProperty(audioKey)) {
//       let audio = new Audio(audioFiles[audioKey]);
//       audio.play().then(() => {
//           console.log("Audio playing successfully");
//       }).catch(error => {
//           console.error("Error playing audio:", error);
//       });
//   } else {
//       console.error("Audio file not found for key:", audioKey);
//   }
// }




document.addEventListener('DOMContentLoaded', function() {
    const langButtons = document.querySelectorAll('.dropdown-content a');
    langButtons.forEach(button => {
        button.addEventListener('click', function(event) {
            event.preventDefault();
            const selectedLang = event.target.id;
            changeLanguage(selectedLang);
        });
    });

    // Apply saved language on page load
    const savedLanguage = localStorage.getItem('language');
    if (savedLanguage) {
        changeLanguage(savedLanguage);
    } else {
        changeLanguage('georgianLang'); // Default language
    }
});

function changeLanguage(language) {
    let langText;
    switch (language) {
        case 'georgianLang':
            langText = 'ენა'; // Georgian for 'Language'
            activeAudioFiles = audioFiles; // Assuming audioFiles contains Georgian audio paths
            break;
       case 'englishLang':
            langText = 'Language'; // English for 'Language'
            activeAudioFiles = audioFilesEnglish;
            break;
        case 'russianLang':
            langText = 'Язык'; // Russian for 'Language'
            activeAudioFiles = audioFilesRussian; // Assuming audioFilesRussian contains Russian audio paths
            break;
        case 'turkishLang':
            langText = 'Dil'; // Turkish for 'Language'
            activeAudioFiles = audioFilesTurkish; // Assuming audioFilesTurkish contains Turkish audio paths
            break;
    }

    localStorage.setItem('language', language);

    // Change text for the drop button to reflect the selected language
    document.querySelector('.dropbtn').textContent = langText;

    // Optionally, you might want to update other UI components to reflect the change in language
    updateButtonText(language);
}


function updateButtonText(language) {
    if (language === 'georgianLang') {
        document.getElementById('routeN1Button').textContent = 'მარშუტი N1, 10კმ';
        document.getElementById('routeN2Button').textContent = 'მარშუტი N2, 8კმ';
        document.getElementById('routeN3Button').textContent = 'Ნინოს ავტოსკოლა';
        document.getElementById('routeN4Button').textContent = 'Მოედანი';
        document.getElementById('toggleMap').textContent = 'ხედის შეცვლა';
    } else if (language === 'englishLang') {
        document.getElementById('routeN1Button').textContent = 'Route N1, 10km';
        document.getElementById('routeN2Button').textContent = 'Route N2, 8km';
        document.getElementById('routeN3Button').textContent = 'Nino\'s Driving School';
        document.getElementById('routeN4Button').textContent = 'Field';
        document.getElementById('toggleMap').textContent = 'Toggle Satellite View';
    } else if (language === 'russianLang') {
        document.getElementById('routeN1Button').textContent = 'Маршрут N1, 10км';
        document.getElementById('routeN2Button').textContent = 'Маршрут N2, 8км';
        document.getElementById('routeN3Button').textContent = 'Автошкола Нино';
        document.getElementById('routeN4Button').textContent = 'Поле';
        document.getElementById('toggleMap').textContent = 'Сменить вид';
    } else if (language === 'turkishLang') {
        document.getElementById('routeN1Button').textContent = 'Rota N1, 10km';
        document.getElementById('routeN2Button').textContent = 'Rota N2, 8km';
        document.getElementById('routeN3Button').textContent = 'Nino\'nun Sürüş Okulu';
        document.getElementById('routeN4Button').textContent = 'Saha';
        document.getElementById('toggleMap').textContent = 'Uydu Görünümü';
    }
}


function playAudio(audioKey) {
    if (activeAudioFiles.hasOwnProperty(audioKey)) {
        let audio = new Audio(activeAudioFiles[audioKey]);
        audio.play().then(() => {
            console.log(`Audio (${localStorage.getItem('language')}): ${audioKey} playing successfully`);
        }).catch(error => {
            console.error("Error playing audio:", error);
        });
    } else {
        console.error(`Audio file not found for key: ${audioKey} in ${localStorage.getItem('language')} language set`);
    }
}

// Continue with the rest of your script.js code...

// Continue with the rest of your script.js code...


// let currentLanguage = 'ქართული'; // Default language
// let activeAudioFiles = audioFiles; // Default to English audio files

// document.addEventListener('DOMContentLoaded', function() {
//     // Check if a language is stored in localStorage and set the currentLanguage variable accordingly
//     if (localStorage.getItem('language')) {
//         currentLanguage = localStorage.getItem('language');
//     } else {
//         currentLanguage = 'ქართული'; // Default to English if no language is stored
//         localStorage.setItem('language', 'ქართული'); // Set default language in localStorage
//     }

//     // Set active audio files based on the current language
//     activeAudioFiles = (currentLanguage === 'Russian') ? audioFilesRussian : audioFiles;

//     // Update button text based on current language
//     document.getElementById('toggleLanguage').textContent = (currentLanguage === 'ქართული') ? 'Russian' : 'ქართული';
// });




// document.getElementById('toggleLanguage').addEventListener('click', function() {
//     // Toggle the language setting
//     currentLanguage = (currentLanguage === 'ქართული') ? 'Russian' : 'ქართული';
    
//     // Store the new language preference in localStorage
//     localStorage.setItem('language', currentLanguage);

//     // Reload the page to apply changes
//     window.location.reload();
// });

// // Ensure the current language is applied right when the page loads
// document.addEventListener('DOMContentLoaded', function() {
//     // Check if a language is stored in localStorage and set the currentLanguage variable accordingly
//     if (localStorage.getItem('language')) {
//         currentLanguage = localStorage.getItem('language');
//     } else {
//         // Default to Georgian if no language is stored
//         currentLanguage = 'ქართული';
//         localStorage.setItem('language', 'ქართული');
//     }

//     // Update all texts immediately on page load
//     updateButtonText();
// });

// // Function to update the text of buttons and other elements based on the current language
// function updateButtonText() {
//     document.getElementById('routeN1Button').textContent = (currentLanguage === 'ქართული') ? 'მარშუტი N1, 10კმ' : 'Маршрут N1';
//     document.getElementById('routeN2Button').textContent = (currentLanguage === 'ქართული') ? 'მარშუტი N2, 8კმ' : 'Маршрут N2';
//     document.getElementById('routeN3Button').textContent = (currentLanguage === 'ქართული') ? 'Ნინოს ავტოსკოლა' : 'Маршрут N3';
//     document.getElementById('routeN4Button').textContent = (currentLanguage === 'ქართული') ? 'Მოედანი' : 'Маршрут N4';
   
//     document.getElementById('toggleMap').textContent = (currentLanguage === 'ქართული') ? 'ხედის შეცვლა' : 'Сменить вид';
//     document.getElementById('toggleLanguage').textContent = (currentLanguage === 'ქართული') ? 'Russian' : 'ქართული';
// }












// function playAudio(audioKey) {
//     // Check if the audioKey exists in the currently active audio files dictionary
//     if (activeAudioFiles.hasOwnProperty(audioKey)) {
//         let audio = new Audio(activeAudioFiles[audioKey]);
//         audio.play().then(() => {
//             console.log(`Audio (${currentLanguage}): ${audioKey} playing successfully`);
//         }).catch(error => {
//             console.error("Error playing audio:", error);
//         });
//     } else {
//         console.error(`Audio file not found for key: ${audioKey} in ${currentLanguage} language set`);
//     }
// }



// Define a variable to track the index of the current checkpoint
let currentCheckpointIndex = 0;

let distanceToNextCheckpoint;



navigator.geolocation.watchPosition((position) => {
    let lat = position.coords.latitude;
    let lng = position.coords.longitude;
    updateUserLocation(lat, lng); // Update the location on the map

    if (currentCheckpointIndex < checkpoints.length) {
        let currentCheckpoint = checkpoints[currentCheckpointIndex];
        let distanceToCurrentCheckpoint = calculateDistance(lat, lng, currentCheckpoint[0], currentCheckpoint[1]);

        if (distanceToCurrentCheckpoint < 231524  && !playedPoints.has(currentCheckpointIndex)) {
            playAudio(currentCheckpoint[2]); // Play audio associated with the current checkpoint
            playedPoints.add(currentCheckpointIndex);
            console.log("Audio played for checkpoint " + (currentCheckpointIndex + 1));
            currentCheckpointIndex++; // Move to the next checkpoint
        }

       // longtext.innerHTML = `<span style="font-weight: bold; color: red;">Distance to the checkpoint ${currentCheckpointIndex + 1}: ${distanceToCurrentCheckpoint.toFixed(0)} meters</span>`;
       longtext.innerHTML = `<span class="distance-text">P ${currentCheckpointIndex + 1}</span>`;


       // longtext.innerHTML = `Distance to the checkpoint ${currentCheckpointIndex + 1}: ${distanceToCurrentCheckpoint.toFixed(0)} meters`;
        console.log(`Real-time distance to current checkpoint: ${distanceToCurrentCheckpoint} meters`);
    } else {
        console.log("You have reached the end of the route.");
    }
}, (err) => {
    console.error("Error getting the position - ", err);
}, {
    enableHighAccuracy: true,
    maximumAge: 100,
    timeout: 5000
});


// // SVG path for the marker icon
// var svgIcon = L.divIcon({
//   className: 'svg-marker-icon',  // Custom class for CSS styling if needed
//   html: '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path fill="CURRENT_COLOR" d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5S10.62 6.5 12 6.5s2.5 1.12 2.5 2.5S13.38 11.5 12 11.5z"/></svg>',
//   iconSize: [24, 24],  // Size of the SVG icon
//   iconAnchor: [12, 24] // Point of the icon that should correspond to marker's location
// });

// // Loop through checkpoints and add markers with custom icons
// checkpoints.forEach((checkpoint, index) => {
//   L.marker([checkpoint[0], checkpoint[1]], {icon: svgIcon}).addTo(map).bindPopup(`Checkpoint ${index + 1}`);
// });


// Add checkpoint markers to the map
checkpoints.forEach((checkpoint, index) => {
    L.marker([checkpoint[0], checkpoint[1]]).addTo(map).bindPopup(`Checkpoint ${index + 1}, Option: ${checkpoint[2]}`);
});



// Function to update the user's location marker on the map
function updateUserLocation(lat, lng) {
  // Remove the previous user location marker if it exists
  if (userLocationMarker) {
      map.removeLayer(userLocationMarker);
  }

  // Define custom marker icon options
  var customIcon = L.icon({
    iconUrl: 'icons/location.png', // URL to the custom icon image
    iconSize: [37, 37], // Size of the icon
    iconAnchor: [16, 32], // Point of the icon which will correspond to marker's location
    popupAnchor: [0, -32] // Point from which the popup should open relative to the iconAnchor
  });

  // Create a new marker for the user's location with custom icon
  userLocationMarker = L.marker([lat, lng], { icon: customIcon }).addTo(map);
}


//Reset

document.addEventListener('DOMContentLoaded', function() {
    var startButton = document.getElementById('startNavigation');
    var startAudio = document.getElementById('audioStart');

    // Check if the audio should play immediately after reloading
    if (localStorage.getItem('playAudioAfterReload') === 'true') {
        startAudio.play().then(() => {
            console.log("Audio is playing after reload."); // Success log
        }).catch(error => {
            console.error("Error playing audio after reload:", error); // Error log
        });

        // Clear the flag so audio doesn't play again on next load unless explicitly set
        localStorage.removeItem('playAudioAfterReload');
    }

    startButton.addEventListener('click', function() {
        console.log('Button clicked, reloading page...'); // Debug log

        // Set flag to play audio after reload
        localStorage.setItem('playAudioAfterReload', 'true');

        // Refresh the page
        location.reload();
    });
});

// Check if the Screen Wake Lock API is supported
if ('wakeLock' in navigator) {
    // Request a screen wake lock
    navigator.wakeLock.request('screen').then(wakeLock => {
        console.log('Screen wake lock activated');
        // You can release the wake lock when it's no longer needed
        // For example, you can release it when the user navigates away from the page or after a certain amount of time
        // wakeLock.release();
    }).catch(err => {
        console.error('Failed to activate screen wake lock:', err);
    });
} else {
    console.warn('Screen Wake Lock API is not supported');
}

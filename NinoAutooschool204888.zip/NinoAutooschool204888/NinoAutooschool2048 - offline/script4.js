let lattext = document.getElementById("lat");
let longtext = document.getElementById("long");
let nearestDistance = document.getElementById("dist");
let userLocationMarker;
let action = document.getElementById("action");
let playedPoints = new Set();


let polylineCoords = [
    [41.9311615, 42.0423683],
    [41.9311813, 42.0423603],
    [41.9311893, 42.0423442],
    [41.9312752, 42.0423247],
    [41.9311893, 42.0423456],
    [41.9311763, 42.0423777],
    [41.9311916, 42.0424465],
    [41.9311321, 42.0422470],
    [41.9311454, 42.0422155],
    [41.9311314, 42.0421726],
    [41.9311095, 42.0421270],
    [41.9311215, 42.0421002],
    [41.9311414, 42.0421082],
    [41.9311574, 42.0421216],
    [41.9311614, 42.0421940],
    [41.9311993, 42.0422262],
    [41.9312767, 42.0422250],
    [41.9312452, 42.0420706],
    [41.9311973, 42.0419419],
    [41.9311248, 42.0419308],
    [41.9310097, 42.0419473],
    [41.9310297, 42.0420974],
    [41.9310717, 42.0422517],
    [41.9311665, 42.0423635]
    

];

  


let checkpoints = [
   
    [41.9311615, 42.0423683,"start"],
    [41.9312752, 42.0423247,"ukuParking"],
    [41.9311916, 42.0424465,"8"],
    [41.9311321, 42.042247,"paralel"],

    [41.9312375, 42.0421417,"errorrrr"],

    [41.9312767, 42.042225,"agmarti"],
    [41.9311248, 42.0419308,"zigzagi"],
    [41.9310717, 42.0422517,"changedirection"],
    [41.9311665, 42.0423635,"stop"],

 
];







// Define the audio files for each option
const audioFiles = {

    "8": "audio/8.mp3",
    "paralel": "audio/paralel.mp3",
    "agmarti": "audio/agmarti.mp3",
    "zigzagi": "audio/zigzagi.mp3",
    "changedirection": "audio/changedirection.mp3",
    "ukuParking": "audio/ukuParking.mp3",

    "start": "audio/start.mp3",
    "start3": "audio/start3.mp3",

    "500left": "audio/500left.mp3",
    "500right": "audio/500right.mp3",
    
    "300left": "audio/300left.mp3",
    "300right": "audio/300right.mp3",

    "100left": "audio/100left.mp3",
    "100right": "audio/100right.mp3",
  
    "left": "audio/left.mp3",
    "Sleft": "audio/Sleft.mp3",

    "right": "audio/right.mp3",
    "Sright": "audio/Sright.mp3",
  

    "directly": "audio/directly.mp3",
    "directlyunstillsigh": "audio/directlyunstillsigh.mp3",

    "leftonCircle": "audio/leftonCircle.mp3",
    "rightonCircle": "audio/rightonCircle.mp3",

    "300leftonCircle": "audio/300leftonCircle.mp3",
    "500leftonCircle": "audio/500leftonCircle.mp3",

    "500rightonCircle": "audio/500rightonCircle.mp3",

    "300rightonCircle": "audio/300rightonCircle.mp3",
    "rightleft": "audio/rightleft.mp3",

    "stop": "audio/stop.mp3"
  

};





const audioFilesRussian = {

    "start": "audior/start.mp3",
    "start3": "audior/start3.mp3",

    "500left": "audior/500left.mp3",
    "500right": "audior/500right.mp3",
    
    "300left": "audior/300left.mp3",
    "300right": "audior/300right.mp3",

    "100left": "audior/100left.mp3",
    "100right": "audior/100right.mp3",
  
    "left": "audior/left.mp3",
    "Sleft": "audior/Sleft.mp3",
    "right": "audior/right.mp3",
    "Sright": "audior/Sright.mp3",
    "directly": "audior/directly.mp3",
    "directlyunstillsigh": "audior/directlyunstillsigh.mp3",
    "leftonCircle": "audior/leftonCircle.mp3",
    "rightonCircle": "audior/rightonCircle.mp3",
    "300leftonCircle": "audior/300leftonCircle.mp3",
    "300rightonCircle": "audior/300rightonCircle.mp3",
    "500leftonCircle": "audior/500leftonCircle.mp3",
    "500rightonCircle": "audior/500rightonCircle.mp3",
    "rightleft": "audior/rightleft.mp3",
    "stop": "audior/stop.mp3"
  
};



const audioFilesTurkish = {
    "start": "audiotr/start.mp3",
    "start3": "audiotr/start3.mp3",
    "500left": "audiotr/500left.mp3",
    "500right": "audiotr/500right.mp3",
    "300left": "audiotr/300left.mp3",
    "300right": "audiotr/300right.mp3",
    "100left": "audiotr/100left.mp3",
    "100right": "audiotr/100right.mp3",
    "left": "audiotr/left.mp3",
    "Sleft": "audiotr/Sleft.mp3",
    "right": "audiotr/right.mp3",
    "Sright": "audiotr/Sright.mp3",
    "directly": "audiotr/directly.mp3",
    "directlyunstillsigh": "audiotr/directlyunstillsigh.mp3",
    "leftonCircle": "audiotr/leftonCircle.mp3",
    "rightonCircle": "audiotr/rightonCircle.mp3",
    "300leftonCircle": "audiotr/300leftonCircle.mp3",
    "300rightonCircle": "audiotr/300rightonCircle.mp3",
    "500leftonCircle": "audiotr/500leftonCircle.mp3",
    "500rightonCircle": "audiotr/500rightonCircle.mp3",
    "rightleft": "audiotr/rightleft.mp3",
    "stop": "audiotr/stop.mp3"
};


const audioFilesEnglish = {
    "start": "audioen/start.mp3",
    "start3": "audioen/start3.mp3",
    "500left": "audioen/500left.mp3",
    "500right": "audioen/500right.mp3",
    "300left": "audioen/300left.mp3",
    "300right": "audioen/300right.mp3",
    "100left": "audioen/100left.mp3",
    "100right": "audioen/100right.mp3",
    "left": "audioen/left.mp3",
    "Sleft": "audioen/Sleft.mp3",
    "right": "audioen/right.mp3",
    "Sright": "audioen/Sright.mp3",
    "directly": "audioen/directly.mp3",
    "directlyunstillsigh": "audioen/directlyunstillsigh.mp3",
    "leftonCircle": "audioen/leftonCircle.mp3",
    "rightonCircle": "audioen/rightonCircle.mp3",
    "300leftonCircle": "audioen/300leftonCircle.mp3",
    "300rightonCircle": "audioen/300rightonCircle.mp3",
    "500leftonCircle": "audioen/500leftonCircle.mp3",
    "500rightonCircle": "audioen/500rightonCircle.mp3",
    "rightleft": "audioen/rightleft.mp3",
    "stop": "audioen/stop.mp3"
};


// Define the options list
const options = ["100right", "right", "left", "100right", "100left","right", "left", "100right", "100left", "left", "100left", "left"]; // Example options list


let sumLat = polylineCoords.reduce((acc, val) => acc + val[0], 0);
let sumLng = polylineCoords.reduce((acc, val) => acc + val[1], 0);

let avgLat = sumLat / polylineCoords.length;
let avgLng = sumLng / polylineCoords.length;

// let map = L.map('map').setView([avgLat, avgLng], 16.3);

// L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
//     attribution: 'Map data &copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a> contributors'
// }).addTo(map);

// Existing map setup code
//let map = L.map('map').setView([41.9228599, 42.0123323], 15.1);

let map = L.map('map', {
    center: [41.9310097, 42.0421969],
    zoom: 18.6,
    dragging: false,  // Disable map dragging
    touchZoom: false, // Optionally disable zooming with touch gestures
    scrollWheelZoom: false // Optionally disable zooming with the scroll wheel
});

// Define the default and satellite layers
// Define the default and satellite layers
let defaultLayer = L.tileLayer('https://{s}.tile.openstreetmap.fr/hot/{z}/{x}/{y}.png', {
    attribution: '©OpenStreetMap contributors, Tiles style by Humanitarian OpenStreetMap Team hosted by OpenStreetMap France'
});

let satelliteLayer = L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', {
    attribution: 'Tiles &copy; Esri &mdash; Source: Esri, i-cubed, USDA, USGS, AEX, GeoEye, Getmapping, Aerogrid, IGN, IGP, UPR-EGP, and the GIS User Community'
}).addTo(map); // Add the satellite layer to the map

// Add functionality to toggle button
document.getElementById('toggleMap').addEventListener('click', function() {
    if (map.hasLayer(defaultLayer)) {
        map.removeLayer(defaultLayer);
        map.addLayer(satelliteLayer);
        // this.textContent = 'Toggle Default View'; // Change button text accordingly
    } else {
        map.removeLayer(satelliteLayer);
        map.addLayer(defaultLayer);
        // this.textContent = 'Toggle Satellite View'; // Reset button text
    }
});



//დროპ

document.addEventListener('DOMContentLoaded', function() {
    const dropdown = document.querySelector('.dropdown');
    const dropbtn = document.querySelector('.dropbtn');
  
    dropbtn.addEventListener('click', function(event) {
      event.stopPropagation(); // Prevent the click event from bubbling up to the document
      dropdown.classList.toggle('show');
    });
  
    // Close the dropdown if the user clicks outside of it
    document.addEventListener('click', function(event) {
      if (!dropdown.contains(event.target)) {
        dropdown.classList.remove('show');
      }
    });
  });
  




let checkpointMarkers = []; // Initialize an empty array to store checkpoint markers

polylineCoords.forEach((coord, index) => {
    let color = 'red';
    if (index === 0) color = 'red'; // Start point
    else if (index === polylineCoords.length - 1) color = 'black'; // End point

    let circleMarker = L.circleMarker(coord, {
        color: color,
        fillColor: 'blue',
        fillOpacity: 1,
        radius:5
    }).addTo(map);

    //animateBreathing(circleMarker); // Apply breathing animation to each marker

    // Store the marker and its index or any other relevant info
    checkpointMarkers.push({
        marker: circleMarker,
        index: index,
        coordinates: coord,
        description: `Checkpoint ${index + 1}`
    });
});



let polyline = L.polyline(polylineCoords, {color: 'red', weight: 6, dashArray: '12, 12'}).addTo(map);


// Function to calculate distance between two points using Haversine formula
function calculateDistance(lat1, lon1, lat2, lon2) {
  const R = 6371e3; // Radius of the Earth in meters
  const φ1 = lat1 * Math.PI / 180; // φ, λ in radians
  const φ2 = lat2 * Math.PI / 180;
  const Δφ = (lat2 - lat1) * Math.PI / 180;
  const Δλ = (lon2 - lon1) * Math.PI / 180;

  const a = Math.sin(Δφ / 2) * Math.sin(Δφ / 2) +
            Math.cos(φ1) * Math.cos(φ2) *
            Math.sin(Δλ / 2) * Math.sin(Δλ / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

  const distance = R * c; // Distance in meters
  return distance;
}



// function playAudio(audioKey) {
//   if (audioFiles.hasOwnProperty(audioKey)) {
//       let audio = new Audio(audioFiles[audioKey]);
//       audio.play().then(() => {
//           console.log("Audio playing successfully");
//       }).catch(error => {
//           console.error("Error playing audio:", error);
//       });
//   } else {
//       console.error("Audio file not found for key:", audioKey);
//   }
// }
document.addEventListener('DOMContentLoaded', function() {
    const langButtons = document.querySelectorAll('.dropdown-content a');
    langButtons.forEach(button => {
        button.addEventListener('click', function(event) {
            event.preventDefault();
            const selectedLang = event.target.id;
            changeLanguage(selectedLang);
        });
    });

    // Apply saved language on page load
    const savedLanguage = localStorage.getItem('language');
    if (savedLanguage) {
        changeLanguage(savedLanguage);
    } else {
        changeLanguage('georgianLang'); // Default language
    }
});

function changeLanguage(language) {
    let langText;
    switch (language) {
        case 'georgianLang':
            langText = 'ენა'; // Georgian for 'Language'
            activeAudioFiles = audioFiles; // Assuming audioFiles contains Georgian audio paths
            break;
       case 'englishLang':
            langText = 'Language'; // English for 'Language'
            activeAudioFiles = audioFilesEnglish;
            break;
        case 'russianLang':
            langText = 'Язык'; // Russian for 'Language'
            activeAudioFiles = audioFilesRussian; // Assuming audioFilesRussian contains Russian audio paths
            break;
        case 'turkishLang':
            langText = 'Dil'; // Turkish for 'Language'
            activeAudioFiles = audioFilesTurkish; // Assuming audioFilesTurkish contains Turkish audio paths
            break;
    }

    localStorage.setItem('language', language);

    // Change text for the drop button to reflect the selected language
    document.querySelector('.dropbtn').textContent = langText;

    // Optionally, you might want to update other UI components to reflect the change in language
    updateButtonText(language);
}


function updateButtonText(language) {
    if (language === 'georgianLang') {
        document.getElementById('routeN1Button').textContent = 'მარშუტი N1, 10კმ';
        document.getElementById('routeN2Button').textContent = 'მარშუტი N2, 8კმ';
        document.getElementById('routeN3Button').textContent = 'Ნინოს ავტოსკოლა';
        document.getElementById('routeN4Button').textContent = 'Მოედანი';
        document.getElementById('toggleMap').textContent = 'ხედის შეცვლა';
    } else if (language === 'englishLang') {
        document.getElementById('routeN1Button').textContent = 'Route N1, 10km';
        document.getElementById('routeN2Button').textContent = 'Route N2, 8km';
        document.getElementById('routeN3Button').textContent = 'Nino\'s Driving School';
        document.getElementById('routeN4Button').textContent = 'Field';
        document.getElementById('toggleMap').textContent = 'Toggle Satellite View';
    } else if (language === 'russianLang') {
        document.getElementById('routeN1Button').textContent = 'Маршрут N1, 10км';
        document.getElementById('routeN2Button').textContent = 'Маршрут N2, 8км';
        document.getElementById('routeN3Button').textContent = 'Автошкола Нино';
        document.getElementById('routeN4Button').textContent = 'Поле';
        document.getElementById('toggleMap').textContent = 'Сменить вид';
    } else if (language === 'turkishLang') {
        document.getElementById('routeN1Button').textContent = 'Rota N1, 10km';
        document.getElementById('routeN2Button').textContent = 'Rota N2, 8km';
        document.getElementById('routeN3Button').textContent = 'Nino\'nun Sürüş Okulu';
        document.getElementById('routeN4Button').textContent = 'Saha';
        document.getElementById('toggleMap').textContent = 'Uydu Görünümü';
    }
}


function playAudio(audioKey) {
    if (activeAudioFiles.hasOwnProperty(audioKey)) {
        let audio = new Audio(activeAudioFiles[audioKey]);
        audio.play().then(() => {
            console.log(`Audio (${localStorage.getItem('language')}): ${audioKey} playing successfully`);
        }).catch(error => {
            console.error("Error playing audio:", error);
        });
    } else {
        console.error(`Audio file not found for key: ${audioKey} in ${localStorage.getItem('language')} language set`);
    }
}


// Define a variable to track the index of the current checkpoint
let currentCheckpointIndex = 0;

let distanceToNextCheckpoint;


// Start watching the user's location with higher accuracy and faster updates



// The logic below remains the same but now uses the options included in the checkpoints array
navigator.geolocation.watchPosition((position) => {
    let lat = position.coords.latitude;
    let lng = position.coords.longitude;
    updateUserLocation(lat, lng); // Update the location on the map

    if (currentCheckpointIndex < checkpoints.length) {
        let currentCheckpoint = checkpoints[currentCheckpointIndex];
        let distanceToCurrentCheckpoint = calculateDistance(lat, lng, currentCheckpoint[0], currentCheckpoint[1]);

        if (distanceToCurrentCheckpoint < 5 && !playedPoints.has(currentCheckpointIndex)) {
            playAudio(currentCheckpoint[2]); // Play audio associated with the current checkpoint
            playedPoints.add(currentCheckpointIndex);
            console.log("Audio played for checkpoint " + (currentCheckpointIndex + 1));
            currentCheckpointIndex++; // Move to the next checkpoint
        }

        longtext.innerHTML = `<span class="distance-text">P ${currentCheckpointIndex + 1}</span>`;

        //longtext.innerHTML = `Distance to the checkpoint ${currentCheckpointIndex + 1}: ${distanceToCurrentCheckpoint.toFixed(0)} meters`;
        console.log(`Real-time distance to current checkpoint: ${distanceToCurrentCheckpoint} meters`);
    } else {
        console.log("You have reached the end of the route.");
    }
}, (err) => {
    console.error("Error getting the position - ", err);
}, {
    enableHighAccuracy: true,
    maximumAge: 100,
    timeout: 5000
});


// Add checkpoint markers to the map
checkpoints.forEach((checkpoint, index) => {
    L.marker([checkpoint[0], checkpoint[1]]).addTo(map).bindPopup(`Checkpoint ${index + 1}, Option: ${checkpoint[2]}`);
});






// =====================================================================================
// Function to update the user's location marker on the map
function updateUserLocation(lat, lng) {
  // Remove the previous user location marker if it exists
  if (userLocationMarker) {
      map.removeLayer(userLocationMarker);
  }

  // Define custom marker icon options
  var customIcon = L.icon({
    iconUrl: 'icons/location.png', // URL to the custom icon image
    iconSize: [37, 37], // Size of the icon
    iconAnchor: [16, 32], // Point of the icon which will correspond to marker's location
    popupAnchor: [0, -32] // Point from which the popup should open relative to the iconAnchor
  });

  // Create a new marker for the user's location with custom icon
  userLocationMarker = L.marker([lat, lng], { icon: customIcon }).addTo(map);
}


//Reset

document.addEventListener('DOMContentLoaded', function() {
    var startButton = document.getElementById('startNavigation');
    var startAudio = document.getElementById('audioStart');

    // Check if the audio should play immediately after reloading
    if (localStorage.getItem('playAudioAfterReload') === 'true') {
        startAudio.play().then(() => {
            console.log("Audio is playing after reload."); // Success log
        }).catch(error => {
            console.error("Error playing audio after reload:", error); // Error log
        });

        // Clear the flag so audio doesn't play again on next load unless explicitly set
        localStorage.removeItem('playAudioAfterReload');
    }

    startButton.addEventListener('click', function() {
        console.log('Button clicked, reloading page...'); // Debug log

        // Set flag to play audio after reload
        localStorage.setItem('playAudioAfterReload', 'true');

        // Refresh the page
        location.reload();
    });
});





// Check if the Screen Wake Lock API is supported
if ('wakeLock' in navigator) {
    // Request a screen wake lock
    navigator.wakeLock.request('screen').then(wakeLock => {
        console.log('Screen wake lock activated');
        // You can release the wake lock when it's no longer needed
        // For example, you can release it when the user navigates away from the page or after a certain amount of time
        // wakeLock.release();
    }).catch(err => {
        console.error('Failed to activate screen wake lock:', err);
    });
} else {
    console.warn('Screen Wake Lock API is not supported');
}

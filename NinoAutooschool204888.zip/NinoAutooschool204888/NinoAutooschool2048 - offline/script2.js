let lattext = document.getElementById("lat");
let longtext = document.getElementById("long");
let nearestDistance = document.getElementById("dist");
let userLocationMarker;
let action = document.getElementById("action");
let playedPoints = new Set();


let polylineCoords = [
    [41.9283837, 42.0305747],
    [41.9276174, 42.0308805],
    [41.9253624, 42.0255643],
    [41.9246799, 42.0238692],
    [41.9240612, 42.0221096],
    [41.9232829, 42.0197922],
    [41.9221095, 42.0165145],
    [41.9216864, 42.0140630],
    [41.9214349, 42.0124537],
    [41.9208761, 42.0090795],
    [41.9209280, 42.0084465],
    [41.9210956, 42.0078027],
    [41.9215427, 42.0065206],
    [41.9216984, 42.0061344],
    [41.9219339, 42.0059681],
    [41.9221893, 42.0058823],
    [41.9227122, 42.0057964],
    [41.9231393, 42.0056784],
    [41.9231552, 42.0045787],
    [41.9231712, 42.0034361],
    [41.9221214, 42.0034361],
    [41.9220935, 42.0022988],
    [41.9210956, 42.0023793],
    [41.9202095, 42.0024598],
    [41.9196148, 42.0024973],
    [41.9186648, 42.0024383],
    [41.9177307, 42.0023954],
    [41.9175511, 42.0017087],
    [41.9174314, 42.0010811],
    [41.9172996, 42.0009685],
    [41.9171879, 42.0009953],
    [41.9170761, 42.0011830],
    [41.9167168, 42.0015961],
    [41.9165811, 42.0021594],
    [41.9165332, 42.0027709],
    [41.9166530, 42.0029479],
    [41.9168007, 42.0029908],
    [41.9169244, 42.0028514],
    [41.9172318, 42.0024759],
    [41.9181179, 42.0025080],
    [41.9188005, 42.0025456],
    [41.9199621, 42.0025617],
    [41.9209520, 42.0024651],
    [41.9210557, 42.0025241],
    [41.9210877, 42.0032322],
    [41.9210717, 42.0039779],
    [41.9211316, 42.0053136],
    [41.9211515, 42.0058179],
    [41.9213152, 42.0060217],
    [41.9214908, 42.0061612],
    [41.9215946, 42.0061827],
    [41.9219179, 42.0060486],
    [41.9221175, 42.0059413],
    [41.9223689, 42.0058984],
    [41.9226443, 42.0058501],
    [41.9232550, 42.0056838],
    [41.9238258, 42.0056033],
    [41.9254183, 42.0054746],
    [41.9270946, 42.0054048],
    [41.9272702, 42.0054370],
    [41.9274338, 42.0054638],
    [41.9274817, 42.0053726],
    [41.9274697, 42.0052439],
    [41.9273979, 42.0051098],
    [41.9273021, 42.0049489],
    [41.9269988, 42.0040423],
    [41.9267314, 42.0032805],
    [41.9264161, 42.0022237],
    [41.9262644, 42.0014888],
    [41.9262684, 42.0011294],
    [41.9262444, 42.0009363],
    [41.9262045, 42.0007432],
    [41.9261327, 42.0006090],
    [41.9260289, 42.0006198],
    [41.9259291, 42.0006627],
    [41.9258932, 42.0007592],
    [41.9259172, 42.0008880],
    [41.9259770, 42.0011079],
    [41.9260369, 42.0013011],
    [41.9261247, 42.0015210],
    [41.9261886, 42.0016766],
    [41.9262524, 42.0018589],
    [41.9263841, 42.0023793],
    [41.9265997, 42.0031303],
    [41.9268551, 42.0038974],
    [41.9270626, 42.0045143],
    [41.9272263, 42.0049810],
    [41.9272702, 42.0052546],
    [41.9273460, 42.0059949],
    [41.9274338, 42.0074540],
    [41.9274777, 42.0077544],
    [41.9276613, 42.0080817],
    [41.9277291, 42.0083767],
    [41.9274617, 42.0086664],
    [41.9262125, 42.0099378],
    [41.9258813, 42.0102757],
    [41.9255021, 42.0105493],
    [41.9245801, 42.0110160],
    [41.9225206, 42.0119870],
    [41.9231432, 42.0135373],
    [41.9239974, 42.0153451],
    [41.9240413, 42.0154738],
    [41.9232909, 42.0159245],
    [41.9224527, 42.0163751],
    [41.9220536, 42.0165575],
    [41.9222492, 42.0171046],
    [41.9225326, 42.0178986],
    [41.9232191, 42.0197439],
    [41.9235943, 42.0209134],
    [41.9239894, 42.0221043],
    [41.9242369, 42.0228070],
    [41.9244763, 42.0235205],
    [41.9248236, 42.0244646],
    [41.9251588, 42.0252746],
    [41.9259890, 42.0272702],
    [41.9266954, 42.0289010],
    [41.9276054, 42.0309663],
    [41.9284715, 42.0306015],
    [41.9288307, 42.0304459]
];

  


let checkpoints = [
    [41.9285114,42.0305157, "start"],               //1
    [41.9282919, 42.0306122, "right"],              //2
    [41.9279486, 42.0307463, "Sright"],
    [41.9275575, 42.0307034, "directlyunstillsigh"], //4


    [41.921407, 42.0123088, "500right"], //5
    [41.9209879, 42.0098412, "300right"],
    [41.9212362, 42.0073496, "rightonCircle"],



    [41.922329, 42.0058501, "leftonCircle"],///teartamde   8
    [41.9231632, 42.0046136, "Sleft"], //mrgvali skami   9

    [41.9229477, 42.003428, "Sright"],//qalaquri    10
    [41.9221494, 42.0031893, "Sleft"],  //univermagi   11

    



    [41.9217726, 42.0023268, "directlyunstillsigh"], //12

    // [41.9205887, 42.0024437, "300right"],
    [41.91999, 42.0024866, "300right"],
    [41.9182656, 42.0024061, "rightleft"], //right then left  14
    

    [41.9176291, 42.0019572, "leftonCircle"],   //15
    [41.917144, 42.0010972, "directly"], // near circle
    [41.9165442, 42.0022132, "Sleft"],  //under the bridge

    [41.9169364, 42.0028407, "Sright"],//18

 
    [41.9185822, 42.0025636, "300right"],
    [41.9202015, 42.0025563, "Sright"],  //20
    [41.9210817, 42.0046017, "leftonCircle"], //makamaia 21

     [41.9222372, 42.0058233, "directly"],

    
    [41.9245239, 42.0055944, "300leftonCircle"], //23

    [41.9266316, 42.005437, "leftonCircle"],


    [41.9272835, 42.0047685, "directlyunstillsigh"], //25
    [41.9264081, 42.0021325, "leftonCircle"],



   



    [41.9260681, 42.0006428, "left"], //




    [41.9259371, 42.0009524, "directlyunstillsigh"],


    [41.927342, 42.005834, "300leftonCircle"],


    [41.9274498, 42.0072287, "leftonCircle"], ///firosmanamde 30


    [41.9275318, 42.0085787, "directlyunstillsigh"],


    [41.9267464, 42.0093534, "500left"],

    [41.9248286, 42.0109088, "300left"],

    [41.9233887, 42.011595, "Sleft"], // kukas battan


    [41.9225964, 42.0121747, "directlyunstillsigh"],


    [41.9238737, 42.0149857, "Sright"],


    [41.9226603, 42.0162302, "Sleft"],  //37




    [41.9223659, 42.0174885, "directlyunstillsigh"],


    [41.9252634, 42.0256098, "500left"],
    [41.9261064, 42.027637, "300left"],


    [41.9271145, 42.0299792, "Sleft"],
    [41.9281402, 42.0307302, "Sleft"],

    [41.9287229, 42.0304674, "stop"]



];







// Define the audio files for each option
const audioFiles = {

    "start": "audio/start.mp3",
    "start3": "audio/start3.mp3",

    "500left": "audio/500left.mp3",
    "500right": "audio/500right.mp3",
    
    "300left": "audio/300left.mp3",
    "300right": "audio/300right.mp3",

    "100left": "audio/100left.mp3",
    "100right": "audio/100right.mp3",
  
    "left": "audio/left.mp3",
    "Sleft": "audio/Sleft.mp3",

    "right": "audio/right.mp3",
    "Sright": "audio/Sright.mp3",
  

    "directly": "audio/directly.mp3",
    "directlyunstillsigh": "audio/directlyunstillsigh.mp3",

    "leftonCircle": "audio/leftonCircle.mp3",
    "rightonCircle": "audio/rightonCircle.mp3",

    "300leftonCircle": "audio/300leftonCircle.mp3",
    "300rightonCircle": "audio/300rightonCircle.mp3",
    "500leftonCircle": "audio/500leftonCircle.mp3",
    "500rightonCircle": "audio/500rightonCircle.mp3",
    "rightleft": "audio/rightleft.mp3",

    "stop": "audio/stop.mp3"
  

};

const audioFilesRussian = {

    "start": "audior/start.mp3",
    "start3": "audior/start3.mp3",

    "500left": "audior/500left.mp3",
    "500right": "audior/500right.mp3",
    
    "300left": "audior/300left.mp3",
    "300right": "audior/300right.mp3",

    "100left": "audior/100left.mp3",
    "100right": "audior/100right.mp3",
  
    "left": "audior/left.mp3",
    "Sleft": "audior/Sleft.mp3",
    "right": "audior/right.mp3",
    "Sright": "audior/Sright.mp3",
    "directly": "audior/directly.mp3",
    "directlyunstillsigh": "audior/directlyunstillsigh.mp3",
    "leftonCircle": "audior/leftonCircle.mp3",
    "rightonCircle": "audior/rightonCircle.mp3",
    "300leftonCircle": "audior/300leftonCircle.mp3",
    "300rightonCircle": "audior/300rightonCircle.mp3",
    "500leftonCircle": "audior/500leftonCircle.mp3",
    "500rightonCircle": "audior/500rightonCircle.mp3",
    "rightleft": "audior/rightleft.mp3",
    "stop": "audior/stop.mp3"
  
};


const audioFilesTurkish = {
    "start": "audiotr/start.mp3",
    "start3": "audiotr/start3.mp3",
    "500left": "audiotr/500left.mp3",
    "500right": "audiotr/500right.mp3",
    "300left": "audiotr/300left.mp3",
    "300right": "audiotr/300right.mp3",
    "100left": "audiotr/100left.mp3",
    "100right": "audiotr/100right.mp3",
    "left": "audiotr/left.mp3",
    "Sleft": "audiotr/Sleft.mp3",
    "right": "audiotr/right.mp3",
    "Sright": "audiotr/Sright.mp3",
    "directly": "audiotr/directly.mp3",
    "directlyunstillsigh": "audiotr/directlyunstillsigh.mp3",
    "leftonCircle": "audiotr/leftonCircle.mp3",
    "rightonCircle": "audiotr/rightonCircle.mp3",
    "300leftonCircle": "audiotr/300leftonCircle.mp3",
    "300rightonCircle": "audiotr/300rightonCircle.mp3",
    "500leftonCircle": "audiotr/500leftonCircle.mp3",
    "500rightonCircle": "audiotr/500rightonCircle.mp3",
    "rightleft": "audiotr/rightleft.mp3",
    "stop": "audiotr/stop.mp3"
};


const audioFilesEnglish = {
    "start": "audioen/start.mp3",
    "start3": "audioen/start3.mp3",
    "500left": "audioen/500left.mp3",
    "500right": "audioen/500right.mp3",
    "300left": "audioen/300left.mp3",
    "300right": "audioen/300right.mp3",
    "100left": "audioen/100left.mp3",
    "100right": "audioen/100right.mp3",
    "left": "audioen/left.mp3",
    "Sleft": "audioen/Sleft.mp3",
    "right": "audioen/right.mp3",
    "Sright": "audioen/Sright.mp3",
    "directly": "audioen/directly.mp3",
    "directlyunstillsigh": "audioen/directlyunstillsigh.mp3",
    "leftonCircle": "audioen/leftonCircle.mp3",
    "rightonCircle": "audioen/rightonCircle.mp3",
    "300leftonCircle": "audioen/300leftonCircle.mp3",
    "300rightonCircle": "audioen/300rightonCircle.mp3",
    "500leftonCircle": "audioen/500leftonCircle.mp3",
    "500rightonCircle": "audioen/500rightonCircle.mp3",
    "rightleft": "audioen/rightleft.mp3",
    "stop": "audioen/stop.mp3"
};



// Define the options list
const options = ["100right", "right", "left", "100right", "100left","right", "left", "100right", "100left", "left", "100left", "left"]; // Example options list


let sumLat = polylineCoords.reduce((acc, val) => acc + val[0], 0);
let sumLng = polylineCoords.reduce((acc, val) => acc + val[1], 0);

let avgLat = sumLat / polylineCoords.length;
let avgLng = sumLng / polylineCoords.length;

// let map = L.map('map').setView([avgLat, avgLng], 16.3);

// L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
//     attribution: 'Map data &copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a> contributors'
// }).addTo(map);

// Existing map setup code
//let map = L.map('map').setView([41.9217662, 42.0145082], 15.2);

let map = L.map('map', {
    center: [41.9217662, 42.0145082],
    zoom: 15.2,
    dragging: false,  // Disable map dragging
    touchZoom: false, // Optionally disable zooming with touch gestures
    scrollWheelZoom: false // Optionally disable zooming with the scroll wheel
});

// Define the default and satellite layers
// Define the default and satellite layers
let defaultLayer = L.tileLayer('https://{s}.tile.openstreetmap.fr/hot/{z}/{x}/{y}.png', {
    attribution: '©OpenStreetMap contributors, Tiles style by Humanitarian OpenStreetMap Team hosted by OpenStreetMap France'
});

let satelliteLayer = L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', {
    attribution: 'Tiles &copy; Esri &mdash; Source: Esri, i-cubed, USDA, USGS, AEX, GeoEye, Getmapping, Aerogrid, IGN, IGP, UPR-EGP, and the GIS User Community'
}).addTo(map); // Add the satellite layer to the map

// Add functionality to toggle button
document.getElementById('toggleMap').addEventListener('click', function() {
    if (map.hasLayer(defaultLayer)) {
        map.removeLayer(defaultLayer);
        map.addLayer(satelliteLayer);
        // this.textContent = 'Toggle Default View'; // Change button text accordingly
    } else {
        map.removeLayer(satelliteLayer);
        map.addLayer(defaultLayer);
        // this.textContent = 'Toggle Satellite View'; // Reset button text
    }
});


//დროპ

document.addEventListener('DOMContentLoaded', function() {
    const dropdown = document.querySelector('.dropdown');
    const dropbtn = document.querySelector('.dropbtn');
  
    dropbtn.addEventListener('click', function(event) {
      event.stopPropagation(); // Prevent the click event from bubbling up to the document
      dropdown.classList.toggle('show');
    });
  
    // Close the dropdown if the user clicks outside of it
    document.addEventListener('click', function(event) {
      if (!dropdown.contains(event.target)) {
        dropdown.classList.remove('show');
      }
    });
  });
  




let checkpointMarkers = []; // Initialize an empty array to store checkpoint markers

polylineCoords.forEach((coord, index) => {
    let color = 'green';
    if (index === 0) color = 'red'; // Start point
    else if (index === polylineCoords.length - 1) color = 'black'; // End point

    let circleMarker = L.circleMarker(coord, {
        color: color,
        fillColor: 'blue',
        fillOpacity: 1,
        radius:5
    }).addTo(map);

    //animateBreathing(circleMarker); // Apply breathing animation to each marker

    // Store the marker and its index or any other relevant info
    checkpointMarkers.push({
        marker: circleMarker,
        index: index,
        coordinates: coord,
        description: `Checkpoint ${index + 1}`
    });
});



let polyline = L.polyline(polylineCoords, {color: 'green', weight: 6, dashArray: '12, 12'}).addTo(map);


// Function to calculate distance between two points using Haversine formula
function calculateDistance(lat1, lon1, lat2, lon2) {
  const R = 6371e3; // Radius of the Earth in meters
  const φ1 = lat1 * Math.PI / 180; // φ, λ in radians
  const φ2 = lat2 * Math.PI / 180;
  const Δφ = (lat2 - lat1) * Math.PI / 180;
  const Δλ = (lon2 - lon1) * Math.PI / 180;

  const a = Math.sin(Δφ / 2) * Math.sin(Δφ / 2) +
            Math.cos(φ1) * Math.cos(φ2) *
            Math.sin(Δλ / 2) * Math.sin(Δλ / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

  const distance = R * c; // Distance in meters
  return distance;
}



// function playAudio(audioKey) {
//   if (audioFiles.hasOwnProperty(audioKey)) {
//       let audio = new Audio(audioFiles[audioKey]);
//       audio.play().then(() => {
//           console.log("Audio playing successfully");
//       }).catch(error => {
//           console.error("Error playing audio:", error);
//       });
//   } else {
//       console.error("Audio file not found for key:", audioKey);
//   }
// }





document.addEventListener('DOMContentLoaded', function() {
    const langButtons = document.querySelectorAll('.dropdown-content a');
    langButtons.forEach(button => {
        button.addEventListener('click', function(event) {
            event.preventDefault();
            const selectedLang = event.target.id;
            changeLanguage(selectedLang);
        });
    });

    // Apply saved language on page load
    const savedLanguage = localStorage.getItem('language');
    if (savedLanguage) {
        changeLanguage(savedLanguage);
    } else {
        changeLanguage('georgianLang'); // Default language
    }
});

function changeLanguage(language) {
    let langText;
    switch (language) {
        case 'georgianLang':
            langText = 'ენა'; // Georgian for 'Language'
            activeAudioFiles = audioFiles; // Assuming audioFiles contains Georgian audio paths
            break;
       case 'englishLang':
            langText = 'Language'; // English for 'Language'
            activeAudioFiles = audioFilesEnglish;
            break;
        case 'russianLang':
            langText = 'Язык'; // Russian for 'Language'
            activeAudioFiles = audioFilesRussian; // Assuming audioFilesRussian contains Russian audio paths
            break;
        case 'turkishLang':
            langText = 'Dil'; // Turkish for 'Language'
            activeAudioFiles = audioFilesTurkish; // Assuming audioFilesTurkish contains Turkish audio paths
            break;
    }

    localStorage.setItem('language', language);

    // Change text for the drop button to reflect the selected language
    document.querySelector('.dropbtn').textContent = langText;

    // Optionally, you might want to update other UI components to reflect the change in language
    updateButtonText(language);
}


function updateButtonText(language) {
    if (language === 'georgianLang') {
        document.getElementById('routeN1Button').textContent = 'მარშუტი N1, 10კმ';
        document.getElementById('routeN2Button').textContent = 'მარშუტი N2, 8კმ';
        document.getElementById('routeN3Button').textContent = 'Ნინოს ავტოსკოლა';
        document.getElementById('routeN4Button').textContent = 'Მოედანი';
        document.getElementById('toggleMap').textContent = 'ხედის შეცვლა';
    } else if (language === 'englishLang') {
        document.getElementById('routeN1Button').textContent = 'Route N1, 10km';
        document.getElementById('routeN2Button').textContent = 'Route N2, 8km';
        document.getElementById('routeN3Button').textContent = 'Nino\'s Driving School';
        document.getElementById('routeN4Button').textContent = 'Field';
        document.getElementById('toggleMap').textContent = 'Toggle Satellite View';
    } else if (language === 'russianLang') {
        document.getElementById('routeN1Button').textContent = 'Маршрут N1, 10км';
        document.getElementById('routeN2Button').textContent = 'Маршрут N2, 8км';
        document.getElementById('routeN3Button').textContent = 'Автошкола Нино';
        document.getElementById('routeN4Button').textContent = 'Поле';
        document.getElementById('toggleMap').textContent = 'Сменить вид';
    } else if (language === 'turkishLang') {
        document.getElementById('routeN1Button').textContent = 'Rota N1, 10km';
        document.getElementById('routeN2Button').textContent = 'Rota N2, 8km';
        document.getElementById('routeN3Button').textContent = 'Nino\'nun Sürüş Okulu';
        document.getElementById('routeN4Button').textContent = 'Saha';
        document.getElementById('toggleMap').textContent = 'Uydu Görünümü';
    }
}


function playAudio(audioKey) {
    if (activeAudioFiles.hasOwnProperty(audioKey)) {
        let audio = new Audio(activeAudioFiles[audioKey]);
        audio.play().then(() => {
            console.log(`Audio (${localStorage.getItem('language')}): ${audioKey} playing successfully`);
        }).catch(error => {
            console.error("Error playing audio:", error);
        });
    } else {
        console.error(`Audio file not found for key: ${audioKey} in ${localStorage.getItem('language')} language set`);
    }
}











// Define a variable to track the index of the current checkpoint
let currentCheckpointIndex = 0;

let distanceToNextCheckpoint;


// Start watching the user's location with higher accuracy and faster updates



// The logic below remains the same but now uses the options included in the checkpoints array
navigator.geolocation.watchPosition((position) => {
    let lat = position.coords.latitude;
    let lng = position.coords.longitude;
    updateUserLocation(lat, lng); // Update the location on the map

    if (currentCheckpointIndex < checkpoints.length) {
        let currentCheckpoint = checkpoints[currentCheckpointIndex];
        let distanceToCurrentCheckpoint = calculateDistance(lat, lng, currentCheckpoint[0], currentCheckpoint[1]);

        if (distanceToCurrentCheckpoint < 13 && !playedPoints.has(currentCheckpointIndex)) {
            playAudio(currentCheckpoint[2]); // Play audio associated with the current checkpoint
            playedPoints.add(currentCheckpointIndex);
            console.log("Audio played for checkpoint " + (currentCheckpointIndex + 1));
            currentCheckpointIndex++; // Move to the next checkpoint
        }

        longtext.innerHTML = `<span class="distance-text">P ${currentCheckpointIndex + 1}</span>`;

        //longtext.innerHTML = `Distance to the checkpoint ${currentCheckpointIndex + 1}: ${distanceToCurrentCheckpoint.toFixed(0)} meters`;
        console.log(`Real-time distance to current checkpoint: ${distanceToCurrentCheckpoint} meters`);
    } else {
        console.log("You have reached the end of the route.");
    }
}, (err) => {
    console.error("Error getting the position - ", err);
}, {
    enableHighAccuracy: true,
    maximumAge: 100,
    timeout: 5000
});


// Add checkpoint markers to the map
checkpoints.forEach((checkpoint, index) => {
    L.marker([checkpoint[0], checkpoint[1]]).addTo(map).bindPopup(`Checkpoint ${index + 1}, Option: ${checkpoint[2]}`);
});






// =====================================================================================
// Function to update the user's location marker on the map
function updateUserLocation(lat, lng) {
  // Remove the previous user location marker if it exists
  if (userLocationMarker) {
      map.removeLayer(userLocationMarker);
  }

  // Define custom marker icon options
  var customIcon = L.icon({
    iconUrl: 'icons/location.png', // URL to the custom icon image
    iconSize: [37, 37], // Size of the icon
    iconAnchor: [16, 32], // Point of the icon which will correspond to marker's location
    popupAnchor: [0, -32] // Point from which the popup should open relative to the iconAnchor
  });

  // Create a new marker for the user's location with custom icon
  userLocationMarker = L.marker([lat, lng], { icon: customIcon }).addTo(map);
}


//Reset

document.addEventListener('DOMContentLoaded', function() {
    var startButton = document.getElementById('startNavigation');
    var startAudio = document.getElementById('audioStart');

    // Check if the audio should play immediately after reloading
    if (localStorage.getItem('playAudioAfterReload') === 'true') {
        startAudio.play().then(() => {
            console.log("Audio is playing after reload."); // Success log
        }).catch(error => {
            console.error("Error playing audio after reload:", error); // Error log
        });

        // Clear the flag so audio doesn't play again on next load unless explicitly set
        localStorage.removeItem('playAudioAfterReload');
    }

    startButton.addEventListener('click', function() {
        console.log('Button clicked, reloading page...'); // Debug log

        // Set flag to play audio after reload
        localStorage.setItem('playAudioAfterReload', 'true');

        // Refresh the page
        location.reload();
    });
});




// Check if the Screen Wake Lock API is supported
if ('wakeLock' in navigator) {
    // Request a screen wake lock
    navigator.wakeLock.request('screen').then(wakeLock => {
        console.log('Screen wake lock activated');
        // You can release the wake lock when it's no longer needed
        // For example, you can release it when the user navigates away from the page or after a certain amount of time
        // wakeLock.release();
    }).catch(err => {
        console.error('Failed to activate screen wake lock:', err);
    });
} else {
    console.warn('Screen Wake Lock API is not supported');
}

let lattext = document.getElementById("lat");
let longtext = document.getElementById("long");
let nearestDistance = document.getElementById("dist");
let userLocationMarker;
let action = document.getElementById("action");
let playedPoints = new Set();


let polylineCoords = [
    [41.9283677,42.0306015],
[41.9289516, 42.0303863],
[41.9295889, 42.0299953],
[41.9296807, 42.0297110],
[41.9293029, 42.0284676],
[41.9284116, 42.0254248],
[41.9284183, 42.0248077],
[41.9282160, 42.0240033],
[41.9285104, 42.0238531],
[41.9289743, 42.0234454],
[41.9290052, 42.0232184],
[41.9270315, 42.0185386],
[41.9260796, 42.0159952],
[41.9248357, 42.0119721],
[41.9245681, 42.0111126],
[41.9249233, 42.0109428],
[41.9255300, 42.0105869],
[41.9260175, 42.0120789],
[41.9266333, 42.0143167],
[41.9267194, 42.0146209],
[41.9269233, 42.0145150],
[41.9276952, 42.0137644],
[41.9285311, 42.0128503],
[41.9291042, 42.0110396],
[41.9291819, 42.0105439],
[41.9290794, 42.0101855],
[41.9288468, 42.0081927],
[41.9286208, 42.0060751],
[41.9281168, 42.0036088],
[41.9276519, 42.0023521],
[41.9282767, 42.0002717],
[41.9288905, 41.9991499],
[41.9293255, 41.9979432],
[41.9297326, 41.9962960],
[41.9287383, 41.9958407],
[41.9284116, 41.9956630],
[41.9282143, 41.9961635],
[41.9279217, 41.9967800],
[41.9267143, 41.9999370],
[41.9264600, 42.0005500],
[41.9259252, 42.0006359],
[41.9256378, 42.0010328],
[41.9249267, 42.0007683],
[41.9249267, 42.0007683],
[41.9242009, 42.0005447],
[41.9235096, 41.9993888],
[41.9231512, 41.9985867],
[41.9227178, 41.9983041],
[41.9223090, 41.9978142],
[41.9222768, 41.9971493],
[41.9223350, 41.9947764],
[41.9223130, 41.9938070],
[41.9220588, 41.9934407],
[41.9219179, 41.9928575],
[41.9216425, 41.9925410],
[41.9210212, 41.9926621],
[41.9207286, 41.9945126],
[41.9194377, 41.9975934],
[41.9184652, 41.9992304],
[41.9174462, 42.0007576],
[41.9171998, 42.0010060],
[41.9171519, 42.0011079],
[41.9171652, 42.0012145],
[41.9172278, 42.0012367],
[41.9173036, 42.0011723],
[41.9176796, 42.0006483],
[41.9192396, 41.9980609],
[41.9205129, 41.9952232],
[41.9208961, 41.9931149],
[41.9210398, 41.9924390],
[41.9213709, 41.9924215],
[41.9218301, 41.9928306],
[41.9220336, 41.9934012],
[41.9222651, 41.9938660],
[41.9222532, 41.9948369],
[41.9222317, 41.9963183],
[41.9222397, 41.9970733],
[41.9222731, 41.9978678],
[41.9228998, 41.9984847],
[41.9231153, 41.9985920],
[41.9233907, 41.9992036],
[41.9238133, 42.0000700],
[41.9241495, 42.0005847],
[41.9252810, 42.0010187],
[41.9256817, 42.0010489],
[41.9260768, 42.0006144],
[41.9265198, 42.0004910],
[41.9268401, 41.9997505],
[41.9272103, 41.9988656],
[41.9277770, 41.9992733],
[41.9282377, 41.9996714],
[41.9284914, 41.9998634],
[41.9282403, 42.0003661],
[41.9276511, 42.0018934],
[41.9276745, 42.0025331],
[41.9279663, 42.0028469],
[41.9283349, 42.0046126],
[41.9286484, 42.0062123],
[41.9288983, 42.0092743],
[41.9291300, 42.0105386],
[41.9290350, 42.0112332],
[41.9286790, 42.0126361],
[41.9275688, 42.0138481],
[41.9274239, 42.0148411],
[41.9280788, 42.0165459],
[41.9285504, 42.0177514],
[41.9295364, 42.0202273],
[41.9303027, 42.0210639],
[41.9290621, 42.0234829],
[41.9281602, 42.0239925],
[41.9283757, 42.0247972],
[41.9283544, 42.0253680],
[41.9287615, 42.0267794],
[41.9294818, 42.0291053],
[41.9297606, 42.0299953],
[41.9290379, 42.0303114],

];

  


let checkpoints = [
    [41.9283677,42.0306015, "start"],
    [41.9289516, 42.0303863, "Sleft"],
    [41.9297056, 42.0296332, "directlyunstillsigh"],
    [41.9293029, 42.0284676, "300right"],
    [41.9284183, 42.0248077, "Sright"],
    [41.9285104, 42.0238531, "Sleft"],
    [41.9290052, 42.0232184, "directlyunstillsigh"],


    [41.9270315, 42.0185386, "500right"],
    [41.9260796, 42.0159952, "300right"],
    [41.9248357, 42.0119721, "Sright"],
    [41.9249233, 42.0109428, "Sright"],
    [41.9256781, 42.011039, "directlyunstillsigh"],

    [41.9260175, 42.0120789, "300left"],
    [41.9264719, 42.0138591, "Sleft"], //10m back   14
    [41.9269233, 42.014515, "directlyunstillsigh"],
    [41.9276952, 42.0137644, "500left"],
    [41.9285311, 42.0128503, "300left"],
    [41.9289145, 42.0117188, "Sleft"],
    [41.9291699, 42.0104367, "directlyunstillsigh"],


    [41.9288468, 42.0081927, "500left"],
    [41.9286208, 42.0060751, "300left"],
    [41.9281168, 42.0036088, "Sleft"],
    [41.927777, 42.0023793, "Sright"], //liandagebmde
    [41.9276493, 42.0021057, "directlyunstillsigh"],//24


    [41.9290182, 41.9988763, "300left"], // 40m back  25
    [41.9295896, 41.9969186, "Sleft"],
    [41.9287383, 41.9958407, "Sleft"],
    [41.9282143, 41.9961635, "directlyunstillsigh"],
    [41.9279217, 41.99678, "300rightonCircle"],//29




    [41.9267143, 41.999937, "rightleft"], //right and left???
    //[41.9249267, 42.0007683, "rightonCircle"],
    [41.9249267, 42.0007683, "rightonCircle"],
    [41.9235096, 41.9993888, "Sleft"],
    [41.9227178, 41.9983041, "Sright"],


    [41.9222768, 41.9971493, "directlyunstillsigh"],
    [41.922335, 41.9947764, "Sleft"],
    [41.9220588, 41.9934407, "leftonCircle"],
    [41.9215933, 41.9926009, "Sleft"],

    [41.9210212, 41.9926621, "directlyunstillsigh"],
    [41.9207286, 41.9945126, "500leftonCircle"],
    [41.9194377, 41.9975934, "300leftonCircle"],
    [41.9175671, 42.0005393, "leftonCircle"], //41


    [41.9171652, 42.0012145, "Sleft"],
    [41.9174713, 42.0009309, "directlyunstillsigh"],
    [41.919279, 41.9980824, "500right"],
    [41.9205587, 41.9952669, "300right"],
    [41.920912, 41.9931847, "Sright"],
    [41.9213709, 41.9924215, "rightonCircle"],
    [41.9219867, 41.9932267, "Sright"], //end of paper 2
    [41.9222811, 41.9940698, "directlyunstillsigh"],
    [41.9222397, 41.9970733, "Sleft"],
    [41.9227002, 41.998297, "Sright"], //tonusi 51
    [41.9238133, 42.00007, "Sleft"],


    [41.9241495, 42.0005847, "leftonCircle"],
    [41.925281, 42.0010187, "leftonCircle"],
    [41.9268401, 41.9997505, "Sright"],

    [41.9273061, 41.9989836, "directlyunstillsigh"],
    [41.9282377, 41.9996714, "Sright"],

    [41.9282403, 42.0003661, "directlyunstillsigh"],

    [41.9276511, 42.0018934, "Sleft"],
    [41.9276745, 42.0025331, "Sright"],
    [41.9279663, 42.0028469, "directlyunstillsigh"],

    [41.9283349, 42.0046126, "500right"],
    [41.9286484, 42.0062123, "300right"],
    [41.9288983, 42.0092743, "Sright"], //edn of 3 paper



    [41.929035, 42.0112332, "directlyunstillsigh"], //paper 4
    [41.9275688, 42.0138481, "Sleft"],
    [41.9274239, 42.0148411, "directlyunstillsigh"],
    [41.9280788, 42.0165459, "500right"],
    [41.9285504, 42.0177514, "300right"],
    [41.9295364, 42.0202273, "Sright"],


    [41.9303027, 42.0210639, "directlyunstillsigh"],
    [41.9288268, 42.0236837, "Sleft"],
    [41.9281829, 42.0242049, "directlyunstillsigh"],
    [41.9283544, 42.025368, "500right"],
    [41.9287615, 42.0267794, "300right"],
    [41.9294818, 42.0291053, "Sright"],
    [41.9290379, 42.0303114, "stop"]
];







// Define the audio files for each option
const audioFiles = {

    "start": "audio/start.mp3",
    "start3": "audio/start3.mp3",

    "500left": "audio/500left.mp3",
    "500right": "audio/500right.mp3",
    
    "300left": "audio/300left.mp3",
    "300right": "audio/300right.mp3",

    "100left": "audio/100left.mp3",
    "100right": "audio/100right.mp3",
  
    "left": "audio/left.mp3",
    "Sleft": "audio/Sleft.mp3",

    "right": "audio/right.mp3",
    "Sright": "audio/Sright.mp3",
  

    "directly": "audio/directly.mp3",
    "directlyunstillsigh": "audio/directlyunstillsigh.mp3",

    "leftonCircle": "audio/leftonCircle.mp3",
    "rightonCircle": "audio/rightonCircle.mp3",

    "300leftonCircle": "audio/300leftonCircle.mp3",
    "500leftonCircle": "audio/500leftonCircle.mp3",

    "500rightonCircle": "audio/500rightonCircle.mp3",

    "300rightonCircle": "audio/300rightonCircle.mp3",
    "rightleft": "audio/rightleft.mp3",

    "stop": "audio/stop.mp3"
  

};





const audioFilesRussian = {

    "start": "audior/start.mp3",
    "start3": "audior/start3.mp3",

    "500left": "audior/500left.mp3",
    "500right": "audior/500right.mp3",
    
    "300left": "audior/300left.mp3",
    "300right": "audior/300right.mp3",

    "100left": "audior/100left.mp3",
    "100right": "audior/100right.mp3",
  
    "left": "audior/left.mp3",
    "Sleft": "audior/Sleft.mp3",
    "right": "audior/right.mp3",
    "Sright": "audior/Sright.mp3",
    "directly": "audior/directly.mp3",
    "directlyunstillsigh": "audior/directlyunstillsigh.mp3",
    "leftonCircle": "audior/leftonCircle.mp3",
    "rightonCircle": "audior/rightonCircle.mp3",
    "300leftonCircle": "audior/300leftonCircle.mp3",
    "300rightonCircle": "audior/300rightonCircle.mp3",
    "500leftonCircle": "audior/500leftonCircle.mp3",
    "500rightonCircle": "audior/500rightonCircle.mp3",
    "rightleft": "audior/rightleft.mp3",
    "stop": "audior/stop.mp3"
  
};


const audioFilesTurkish = {
    "start": "audiotr/start.mp3",
    "start3": "audiotr/start3.mp3",
    "500left": "audiotr/500left.mp3",
    "500right": "audiotr/500right.mp3",
    "300left": "audiotr/300left.mp3",
    "300right": "audiotr/300right.mp3",
    "100left": "audiotr/100left.mp3",
    "100right": "audiotr/100right.mp3",
    "left": "audiotr/left.mp3",
    "Sleft": "audiotr/Sleft.mp3",
    "right": "audiotr/right.mp3",
    "Sright": "audiotr/Sright.mp3",
    "directly": "audiotr/directly.mp3",
    "directlyunstillsigh": "audiotr/directlyunstillsigh.mp3",
    "leftonCircle": "audiotr/leftonCircle.mp3",
    "rightonCircle": "audiotr/rightonCircle.mp3",
    "300leftonCircle": "audiotr/300leftonCircle.mp3",
    "300rightonCircle": "audiotr/300rightonCircle.mp3",
    "500leftonCircle": "audiotr/500leftonCircle.mp3",
    "500rightonCircle": "audiotr/500rightonCircle.mp3",
    "rightleft": "audiotr/rightleft.mp3",
    "stop": "audiotr/stop.mp3"
};


const audioFilesEnglish = {
    "start": "audioen/start.mp3",
    "start3": "audioen/start3.mp3",
    "500left": "audioen/500left.mp3",
    "500right": "audioen/500right.mp3",
    "300left": "audioen/300left.mp3",
    "300right": "audioen/300right.mp3",
    "100left": "audioen/100left.mp3",
    "100right": "audioen/100right.mp3",
    "left": "audioen/left.mp3",
    "Sleft": "audioen/Sleft.mp3",
    "right": "audioen/right.mp3",
    "Sright": "audioen/Sright.mp3",
    "directly": "audioen/directly.mp3",
    "directlyunstillsigh": "audioen/directlyunstillsigh.mp3",
    "leftonCircle": "audioen/leftonCircle.mp3",
    "rightonCircle": "audioen/rightonCircle.mp3",
    "300leftonCircle": "audioen/300leftonCircle.mp3",
    "300rightonCircle": "audioen/300rightonCircle.mp3",
    "500leftonCircle": "audioen/500leftonCircle.mp3",
    "500rightonCircle": "audioen/500rightonCircle.mp3",
    "rightleft": "audioen/rightleft.mp3",
    "stop": "audioen/stop.mp3"
};




// Define the options list
const options = ["100right", "right", "left", "100right", "100left","right", "left", "100right", "100left", "left", "100left", "left"]; // Example options list


let sumLat = polylineCoords.reduce((acc, val) => acc + val[0], 0);
let sumLng = polylineCoords.reduce((acc, val) => acc + val[1], 0);

let avgLat = sumLat / polylineCoords.length;
let avgLng = sumLng / polylineCoords.length;

// let map = L.map('map').setView([avgLat, avgLng], 16.3);

// L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
//     attribution: 'Map data &copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a> contributors'
// }).addTo(map);

// Existing map setup code
//let map = L.map('map').setView([41.9228599, 42.0123323], 15.1);

let map = L.map('map', {
    center: [41.9228599, 42.0123323],
    zoom: 15.1,
    dragging: false,  // Disable map dragging
    touchZoom: false, // Optionally disable zooming with touch gestures
    scrollWheelZoom: false // Optionally disable zooming with the scroll wheel
});

// Define the default and satellite layers
// Define the default and satellite layers
let defaultLayer = L.tileLayer('https://{s}.tile.openstreetmap.fr/hot/{z}/{x}/{y}.png', {
    attribution: '©OpenStreetMap contributors, Tiles style by Humanitarian OpenStreetMap Team hosted by OpenStreetMap France'
});

let satelliteLayer = L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', {
    attribution: 'Tiles &copy; Esri &mdash; Source: Esri, i-cubed, USDA, USGS, AEX, GeoEye, Getmapping, Aerogrid, IGN, IGP, UPR-EGP, and the GIS User Community'
}).addTo(map); // Add the satellite layer to the map

// Add functionality to toggle button
document.getElementById('toggleMap').addEventListener('click', function() {
    if (map.hasLayer(defaultLayer)) {
        map.removeLayer(defaultLayer);
        map.addLayer(satelliteLayer);
        // this.textContent = 'Toggle Default View'; // Change button text accordingly
    } else {
        map.removeLayer(satelliteLayer);
        map.addLayer(defaultLayer);
        // this.textContent = 'Toggle Satellite View'; // Reset button text
    }
});



//დროპ

document.addEventListener('DOMContentLoaded', function() {
    const dropdown = document.querySelector('.dropdown');
    const dropbtn = document.querySelector('.dropbtn');
  
    dropbtn.addEventListener('click', function(event) {
      event.stopPropagation(); // Prevent the click event from bubbling up to the document
      dropdown.classList.toggle('show');
    });
  
    // Close the dropdown if the user clicks outside of it
    document.addEventListener('click', function(event) {
      if (!dropdown.contains(event.target)) {
        dropdown.classList.remove('show');
      }
    });
  });
  




let checkpointMarkers = []; // Initialize an empty array to store checkpoint markers

polylineCoords.forEach((coord, index) => {
    let color = 'red';
    if (index === 0) color = 'red'; // Start point
    else if (index === polylineCoords.length - 1) color = 'black'; // End point

    let circleMarker = L.circleMarker(coord, {
        color: color,
        fillColor: 'blue',
        fillOpacity: 1,
        radius:5
    }).addTo(map);

    //animateBreathing(circleMarker); // Apply breathing animation to each marker

    // Store the marker and its index or any other relevant info
    checkpointMarkers.push({
        marker: circleMarker,
        index: index,
        coordinates: coord,
        description: `Checkpoint ${index + 1}`
    });
});



let polyline = L.polyline(polylineCoords, {color: 'red', weight: 6, dashArray: '12, 12'}).addTo(map);


// Function to calculate distance between two points using Haversine formula
function calculateDistance(lat1, lon1, lat2, lon2) {
  const R = 6371e3; // Radius of the Earth in meters
  const φ1 = lat1 * Math.PI / 180; // φ, λ in radians
  const φ2 = lat2 * Math.PI / 180;
  const Δφ = (lat2 - lat1) * Math.PI / 180;
  const Δλ = (lon2 - lon1) * Math.PI / 180;

  const a = Math.sin(Δφ / 2) * Math.sin(Δφ / 2) +
            Math.cos(φ1) * Math.cos(φ2) *
            Math.sin(Δλ / 2) * Math.sin(Δλ / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

  const distance = R * c; // Distance in meters
  return distance;
}



// function playAudio(audioKey) {
//   if (audioFiles.hasOwnProperty(audioKey)) {
//       let audio = new Audio(audioFiles[audioKey]);
//       audio.play().then(() => {
//           console.log("Audio playing successfully");
//       }).catch(error => {
//           console.error("Error playing audio:", error);
//       });
//   } else {
//       console.error("Audio file not found for key:", audioKey);
//   }
// }

document.addEventListener('DOMContentLoaded', function() {
    const langButtons = document.querySelectorAll('.dropdown-content a');
    langButtons.forEach(button => {
        button.addEventListener('click', function(event) {
            event.preventDefault();
            const selectedLang = event.target.id;
            changeLanguage(selectedLang);
        });
    });

    // Apply saved language on page load
    const savedLanguage = localStorage.getItem('language');
    if (savedLanguage) {
        changeLanguage(savedLanguage);
    } else {
        changeLanguage('georgianLang'); // Default language
    }
});

function changeLanguage(language) {
    let langText;
    switch (language) {
        case 'georgianLang':
            langText = 'ენა'; // Georgian for 'Language'
            activeAudioFiles = audioFiles; // Assuming audioFiles contains Georgian audio paths
            break;
       case 'englishLang':
            langText = 'Language'; // English for 'Language'
            activeAudioFiles = audioFilesEnglish;
            break;
        case 'russianLang':
            langText = 'Язык'; // Russian for 'Language'
            activeAudioFiles = audioFilesRussian; // Assuming audioFilesRussian contains Russian audio paths
            break;
        case 'turkishLang':
            langText = 'Dil'; // Turkish for 'Language'
            activeAudioFiles = audioFilesTurkish; // Assuming audioFilesTurkish contains Turkish audio paths
            break;
    }

    localStorage.setItem('language', language);

    // Change text for the drop button to reflect the selected language
    document.querySelector('.dropbtn').textContent = langText;

    // Optionally, you might want to update other UI components to reflect the change in language
    updateButtonText(language);
}


function updateButtonText(language) {
    if (language === 'georgianLang') {
        document.getElementById('routeN1Button').textContent = 'მარშუტი N1, 10კმ';
        document.getElementById('routeN2Button').textContent = 'მარშუტი N2, 8კმ';
        document.getElementById('routeN3Button').textContent = 'Ნინოს ავტოსკოლა';
        document.getElementById('routeN4Button').textContent = 'Მოედანი';
        document.getElementById('toggleMap').textContent = 'ხედის შეცვლა';
    } else if (language === 'englishLang') {
        document.getElementById('routeN1Button').textContent = 'Route N1, 10km';
        document.getElementById('routeN2Button').textContent = 'Route N2, 8km';
        document.getElementById('routeN3Button').textContent = 'Nino\'s Driving School';
        document.getElementById('routeN4Button').textContent = 'Field';
        document.getElementById('toggleMap').textContent = 'Toggle Satellite View';
    } else if (language === 'russianLang') {
        document.getElementById('routeN1Button').textContent = 'Маршрут N1, 10км';
        document.getElementById('routeN2Button').textContent = 'Маршрут N2, 8км';
        document.getElementById('routeN3Button').textContent = 'Автошкола Нино';
        document.getElementById('routeN4Button').textContent = 'Поле';
        document.getElementById('toggleMap').textContent = 'Сменить вид';
    } else if (language === 'turkishLang') {
        document.getElementById('routeN1Button').textContent = 'Rota N1, 10km';
        document.getElementById('routeN2Button').textContent = 'Rota N2, 8km';
        document.getElementById('routeN3Button').textContent = 'Nino\'nun Sürüş Okulu';
        document.getElementById('routeN4Button').textContent = 'Saha';
        document.getElementById('toggleMap').textContent = 'Uydu Görünümü';
    }
}


function playAudio(audioKey) {
    if (activeAudioFiles.hasOwnProperty(audioKey)) {
        let audio = new Audio(activeAudioFiles[audioKey]);
        audio.play().then(() => {
            console.log(`Audio (${localStorage.getItem('language')}): ${audioKey} playing successfully`);
        }).catch(error => {
            console.error("Error playing audio:", error);
        });
    } else {
        console.error(`Audio file not found for key: ${audioKey} in ${localStorage.getItem('language')} language set`);
    }
}


// Define a variable to track the index of the current checkpoint
let currentCheckpointIndex = 0;

let distanceToNextCheckpoint;


// Start watching the user's location with higher accuracy and faster updates



// The logic below remains the same but now uses the options included in the checkpoints array
navigator.geolocation.watchPosition((position) => {
    let lat = position.coords.latitude;
    let lng = position.coords.longitude;
    updateUserLocation(lat, lng); // Update the location on the map

    if (currentCheckpointIndex < checkpoints.length) {
        let currentCheckpoint = checkpoints[currentCheckpointIndex];
        let distanceToCurrentCheckpoint = calculateDistance(lat, lng, currentCheckpoint[0], currentCheckpoint[1]);

        if (distanceToCurrentCheckpoint < 13 && !playedPoints.has(currentCheckpointIndex)) {
            playAudio(currentCheckpoint[2]); // Play audio associated with the current checkpoint
            playedPoints.add(currentCheckpointIndex);
            console.log("Audio played for checkpoint " + (currentCheckpointIndex + 1));
            currentCheckpointIndex++; // Move to the next checkpoint
        }

        longtext.innerHTML = `<span class="distance-text">P ${currentCheckpointIndex + 1}</span>`;

        //longtext.innerHTML = `Distance to the checkpoint ${currentCheckpointIndex + 1}: ${distanceToCurrentCheckpoint.toFixed(0)} meters`;
        console.log(`Real-time distance to current checkpoint: ${distanceToCurrentCheckpoint} meters`);
    } else {
        console.log("You have reached the end of the route.");
    }
}, (err) => {
    console.error("Error getting the position - ", err);
}, {
    enableHighAccuracy: true,
    maximumAge: 100,
    timeout: 5000
});


// Add checkpoint markers to the map
checkpoints.forEach((checkpoint, index) => {
    L.marker([checkpoint[0], checkpoint[1]]).addTo(map).bindPopup(`Checkpoint ${index + 1}, Option: ${checkpoint[2]}`);
});






// =====================================================================================
// Function to update the user's location marker on the map
function updateUserLocation(lat, lng) {
  // Remove the previous user location marker if it exists
  if (userLocationMarker) {
      map.removeLayer(userLocationMarker);
  }

  // Define custom marker icon options
  var customIcon = L.icon({
    iconUrl: 'icons/location.png', // URL to the custom icon image
    iconSize: [37, 37], // Size of the icon
    iconAnchor: [16, 32], // Point of the icon which will correspond to marker's location
    popupAnchor: [0, -32] // Point from which the popup should open relative to the iconAnchor
  });

  // Create a new marker for the user's location with custom icon
  userLocationMarker = L.marker([lat, lng], { icon: customIcon }).addTo(map);
}


//Reset

document.addEventListener('DOMContentLoaded', function() {
    var startButton = document.getElementById('startNavigation');
    var startAudio = document.getElementById('audioStart');

    // Check if the audio should play immediately after reloading
    if (localStorage.getItem('playAudioAfterReload') === 'true') {
        startAudio.play().then(() => {
            console.log("Audio is playing after reload."); // Success log
        }).catch(error => {
            console.error("Error playing audio after reload:", error); // Error log
        });

        // Clear the flag so audio doesn't play again on next load unless explicitly set
        localStorage.removeItem('playAudioAfterReload');
    }

    startButton.addEventListener('click', function() {
        console.log('Button clicked, reloading page...'); // Debug log

        // Set flag to play audio after reload
        localStorage.setItem('playAudioAfterReload', 'true');

        // Refresh the page
        location.reload();
    });
});





// Check if the Screen Wake Lock API is supported
if ('wakeLock' in navigator) {
    // Request a screen wake lock
    navigator.wakeLock.request('screen').then(wakeLock => {
        console.log('Screen wake lock activated');
        // You can release the wake lock when it's no longer needed
        // For example, you can release it when the user navigates away from the page or after a certain amount of time
        // wakeLock.release();
    }).catch(err => {
        console.error('Failed to activate screen wake lock:', err);
    });
} else {
    console.warn('Screen Wake Lock API is not supported');
}
